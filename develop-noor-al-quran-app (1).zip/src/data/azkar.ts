export type AzkarCategoryId = "morning" | "evening" | "prayer" | "sleep" | "tasbih";

export interface AzkarItem {
  id: string;
  text: string;
  reference: string;
  count?: number; // recommended repetitions
}

export interface AzkarCategory {
  id: AzkarCategoryId;
  title: string;
  subtitle: string;
  color: string;
  icon: string;
  items: AzkarItem[];
}

export const AZKAR: AzkarCategory[] = [
  {
    id: "morning",
    title: "أذكار الصباح",
    subtitle: "من الفجر حتى شروق الشمس",
    color: "bg-amber-50 dark:bg-amber-900/20",
    icon: "🌅",
    items: [
      {
        id: "morning-1",
        text: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ رَبِّ الْعَالَمِينَ، اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ هَذَا يَوْمٍ، فَتْحَهُ وَنَصْرَهُ وَنُورَهُ وَبَرَكَتَهُ وَهُدَاهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِيهِ وَشَرِّ مَا بَعْدَهُ",
        reference: "مسلم",
        count: 1,
      },
      {
        id: "morning-2",
        text: "لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
        reference: "البخاري، مسلم",
        count: 10,
      },
      {
        id: "morning-3",
        text: "حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ، عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ",
        reference: "أبو داود",
        count: 7,
      },
    ],
  },
  {
    id: "evening",
    title: "أذكار المساء",
    subtitle: "من المغرب حتى منتصف الليل",
    color: "bg-indigo-50 dark:bg-indigo-900/20",
    icon: "🌙",
    items: [
      {
        id: "evening-1",
        text: "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ رَبِّ الْعَالَمِينَ، اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ هَذِهِ لَيْلَةٍ، فَتْحَهَا وَنَصْرَهَا وَنُورَهَا وَبَرَكَتَهَا وَهُدَاهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِيهَا وَشَرِّ مَا بَعْدَهَا",
        reference: "مسلم",
        count: 1,
      },
      {
        id: "evening-2",
        text: "أَمْسَيْنَا عَلَى فِطْرَةِ الْإِسْلَامِ، وَعَلَى كَلِمَةِ الْإِخْلَاصِ، وَعَلَى دِينِ نَبِيِّنَا مُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ، وَعَلَى مِلَّةِ أَبِينَا إِبْرَاهِيمَ حَنِيفًا مُسْلِمًا وَمَا كَانَ مِنَ الْمُشْرِكِينَ",
        reference: "الحاكم",
        count: 1,
      },
    ],
  },
  {
    id: "prayer",
    title: "أذكار بعد الصلاة",
    subtitle: "أدعية وأذكار تُقال عقب الفريضة",
    color: "bg-emerald-50 dark:bg-emerald-900/20",
    icon: "🕌",
    items: [
      {
        id: "prayer-1",
        text: "أَسْتَغْفِرُ اللَّهَ (3 مرات)، اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ",
        reference: "مسلم",
        count: 3,
      },
      {
        id: "prayer-2",
        text: "اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ",
        reference: "أبو داود، النسائي",
        count: 1,
      },
      {
        id: "prayer-3",
        text: "سُبْحَانَ اللَّهِ (33)، الْحَمْدُ لِلَّهِ (33)، اللَّهُ أَكْبَر (34)",
        reference: "فاطمة رضي الله عنها",
        count: 1,
      },
    ],
  },
  {
    id: "sleep",
    title: "أذكار النوم",
    subtitle: "قبل النوم وخلال اليوم",
    color: "bg-slate-50 dark:bg-slate-900/20",
    icon: "😴",
    items: [
      {
        id: "sleep-1",
        text: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",
        reference: "البخاري، مسلم",
        count: 1,
      },
      {
        id: "sleep-2",
        text: "اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ (3 مرات)",
        reference: "أبو داود، الترمذي",
        count: 3,
      },
      {
        id: "sleep-3",
        text: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ (3 مرات)",
        reference: "مسلم",
        count: 3,
      },
    ],
  },
  {
    id: "tasbih",
    title: "التسبيح",
    subtitle: "عداد إلكتروني للأذكار والتسبيحات",
    color: "bg-rose-50 dark:bg-rose-900/20",
    icon: "📿",
    items: [
      {
        id: "tasbih-subhan",
        text: "سُبْحَانَ اللَّهِ",
        reference: "التسبيح",
        count: 33,
      },
      {
        id: "tasbih-alhamd",
        text: "الْحَمْدُ لِلَّهِ",
        reference: "الحمد",
        count: 33,
      },
      {
        id: "tasbih-allahu-akbar",
        text: "اللَّهُ أَكْبَر",
        reference: "التكبير",
        count: 34,
      },
    ],
  },
];
