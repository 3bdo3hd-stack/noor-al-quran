import type { SurahMeta } from "@/data/surahs";
import { SURAHS, SURAHS_BY_ID } from "@/data/surahs";
import ayahsRaw from "@/data/quran-ayahs.json";

export interface Ayah {
  id: number;
  number: number; // global ayah number 1..6236
  text: string; // Uthmani script
  numberInSurah: number;
  page: number;
  surahId: number;
  rubId: number;
  hizbId: number;
  juzId: number;
  sajda: boolean;
}

type RawAyah = {
  id: number;
  number: number;
  text: string;
  number_in_surah: number;
  page: number;
  surah_id: number;
  rub_id: number;
  hizb_id: number;
  juz_id: number;
  sajda: boolean;
};

export const AYAHS: Ayah[] = (ayahsRaw as RawAyah[]).map((a) => ({
  id: a.id,
  number: a.number,
  text: a.text,
  numberInSurah: a.number_in_surah,
  page: a.page,
  surahId: a.surah_id,
  rubId: a.rub_id,
  hizbId: a.hizb_id,
  juzId: a.juz_id,
  sajda: a.sajda,
}));

const TOTAL_AYAHS = AYAHS.length; // 6236

// Count ayahs per surah from the authoritative text.
const AYAH_COUNT_PER_SURAH = new Map<number, number>();
for (const a of AYAHS) {
  AYAH_COUNT_PER_SURAH.set(
    a.surahId,
    (AYAH_COUNT_PER_SURAH.get(a.surahId) ?? 0) + 1,
  );
}

/** Get all surahs with verse counts derived from the Qur'anic text. */
export function getSurahsWithCount(): (SurahMeta & { totalAyahs: number })[] {
  return SURAHS.map((s: SurahMeta) => ({
    ...s,
    totalAyahs: AYAH_COUNT_PER_SURAH.get(s.id) ?? 0,
  }));
}

export function getSurah(surahId: number) {
  const meta = getSurahsWithCount().find((s) => s.id === surahId);
  if (!meta) return null;
  const ayahs = AYAHS.filter((a) => a.surahId === surahId).sort(
    (a, b) => a.numberInSurah - b.numberInSurah,
  );
  return { ...meta, ayahs };
}

export function getAyah(surahId: number, ayahInSurah: number) {
  return AYAHS.find(
    (a) => a.surahId === surahId && a.numberInSurah === ayahInSurah,
  );
}

export function getAyahByGlobalNumber(globalNumber: number) {
  return AYAHS.find((a) => a.number === globalNumber);
}

export function getAyahById(id: number) {
  return AYAHS.find((a) => a.id === id);
}

export function getNextAyah(surahId: number, ayahInSurah: number) {
  const surah = getSurah(surahId);
  if (!surah) return null;
  const idx = surah.ayahs.findIndex(
    (a) => a.numberInSurah === ayahInSurah,
  );
  if (idx === -1 || idx === surah.ayahs.length - 1) {
    const nextSurah = getSurah(surahId + 1);
    if (!nextSurah) return null;
    return { surahId: nextSurah.id, ayahInSurah: 1 };
  }
  return { surahId, ayahInSurah: surah.ayahs[idx + 1].numberInSurah };
}

export function getPrevAyah(surahId: number, ayahInSurah: number) {
  const surah = getSurah(surahId);
  if (!surah) return null;
  const idx = surah.ayahs.findIndex(
    (a) => a.numberInSurah === ayahInSurah,
  );
  if (idx === -1) return null;
  if (idx === 0) {
    const prevSurah = getSurah(surahId - 1);
    if (!prevSurah) return null;
    const last = prevSurah.ayahs[prevSurah.ayahs.length - 1];
    return { surahId: prevSurah.id, ayahInSurah: last.numberInSurah };
  }
  return { surahId, ayahInSurah: surah.ayahs[idx - 1].numberInSurah };
}

export function getPageAyahs(page: number) {
  return AYAHS.filter((a) => a.page === page).sort(
    (a, b) => a.surahId - b.surahId || a.numberInSurah - b.numberInSurah,
  );
}

export function getSurahsOnPage(page: number) {
  const ayahs = getPageAyahs(page);
  const surahIds = [...new Set(ayahs.map((a) => a.surahId))];
  return surahIds.map((id) => {
    const s = getSurah(id);
    const pageAyahs = ayahs.filter((a) => a.surahId === id);
    return {
      surah: s!,
      firstAyah: pageAyahs[0],
      lastAyah: pageAyahs[pageAyahs.length - 1],
      ayahCount: pageAyahs.length,
    };
  });
}

export function getJuzAyahs(juz: number) {
  return AYAHS.filter((a) => a.juzId === juz).sort(
    (a, b) => a.surahId - b.surahId || a.numberInSurah - b.numberInSurah,
  );
}

export function getHizbAyahs(hizb: number) {
  return AYAHS.filter((a) => a.hizbId === hizb).sort(
    (a, b) => a.surahId - b.surahId || a.numberInSurah - b.numberInSurah,
  );
}

export function searchAyahs(query: string, limit = 50) {
  const q = query.trim();
  if (!q) return [];
  const results = AYAHS.filter((a) => a.text.includes(q));
  return results
    .map((a) => {
      const surah = getSurahsWithCount().find((s) => s.id === a.surahId);
      return { ...a, surahNameAr: surah?.nameAr, surahId: a.surahId };
    })
    .slice(0, limit);
}

export function getTotalAyahs() {
  return TOTAL_AYAHS;
}

export function getSurahRange(surahId: number) {
  const surah = getSurah(surahId);
  if (!surah) return null;
  return {
    first: surah.ayahs[0].number,
    last: surah.ayahs[surah.ayahs.length - 1].number,
  };
}

export function getJuzCount() {
  return 30;
}

export function getHizbCount() {
  return 60;
}

export function getPageCount() {
  return 604; // standard Madinah mushaf pages
}

export { SURAHS, SURAHS_BY_ID };
