import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Providers } from "@/components/providers";
import { Navbar } from "@/components/layout/navbar";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { AudioPlayer } from "@/components/audio/audio-player";

export const metadata: Metadata = {
  title: {
    template: "%s | نور القرآن",
    default: "نور القرآن | NOOR AL-QURAN",
  },
  description:
    "تطبيق قرآني متكامل Profesionally crafted — مصحف عثماني، تلاوات صوتية، تفسير، ترجمة، مواقيت صلاة، أذكار، وحفظ القرآن.",
  keywords: [
    "قرآن",
    "المصحف",
    "نور القرآن",
    "Quran",
    "مواقيت الصلاة",
    "تفسير",
    "أذكار",
    "حفظ القرآن",
  ],
  openGraph: {
    title: "نور القرآن | NOOR AL-QURAN",
    description: "تطبيق قرآني متكامل احترافي",
    type: "website",
    locale: "ar_SA",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <Providers>
      <html lang="ar" dir="rtl" className="scroll-smooth">
        <body
          className="bg-islamic-cream text-slate-900 dark:bg-islamic-dark dark:text-slate-200 min-h-screen font-sans"
        >
          <div className="flex flex-col min-h-[100vh]">
            <Navbar />
            <main className="flex-1 relative z-0 pb-20">{children}</main>
          </div>
          <ThemeToggle />
          <AudioPlayer />
        </body>
      </html>
    </Providers>
  );
}
