"use client";

import React, { useEffect, useState } from "react";
import { ensureUser, upsertAzkar } from "@/app/actions";
import { AZKAR, type AzkarCategory } from "@/data/azkar";
import { Plus, Minus, Check, RefreshCw, Play } from "lucide-react";
import { cn } from "@/lib/utils";

export default function AzkarPage() {
  const [userId, setUserId] = useState<number | null>(null);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [completed, setCompleted] = useState<Record<string, boolean>>({});
  const [activeTasbih, setActiveTasbih] = useState<string | null>(null);
  const [tasbihCount, setTasbihCount] = useState(0);

  useEffect(() => {
    ensureUser().then((u) => setUserId(u.id));
  }, []);

  const handleIncrement = (id: string) => {
    setCounts((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));
    if (activeTasbih === id) setTasbihCount((c) => c + 1);
    if (userId) {
      const cat = AZKAR.find((c) => c.items.some((i) => i.id === id))!;
      upsertAzkar({ userId, category: cat.id, itemId: id, count: 1 });
    }
  };

  const handleDecrement = (id: string) => {
    setCounts((c) => {
      const next = Math.max(0, (c[id] || 0) - 1);
      return { ...c, [id]: next };
    });
    if (activeTasbih === id) setTasbihCount((c) => Math.max(0, c - 1));
  };

  const handleReset = (id: string) => {
    setCounts((c) => ({ ...c, [id]: 0 }));
    if (activeTasbih === id) setTasbihCount(0);
  };

  const toggleComplete = (id: string) => {
    setCompleted((c) => ({ ...c, [id]: !(c[id] || false) }));
  };

  const countFor = (id: string) => counts[id] || 0;

  return (
    <div className="mx-auto max-w-3xl px-5 py-10 space-y-8">
      <h1 className="font-arabic text-2xl font-bold text-slate-900 dark:text-white">
        الأذكار والأدعية
      </h1>

      {AZKAR.map((cat) => (
        <section key={cat.id} className="space-y-3">
          <div className={cn("rounded-2xl p-4 flex items-center gap-3", cat.color)}>
            <span className="text-2xl">{cat.icon}</span>
            <div>
              <div className="font-bold text-slate-900 dark:text-white">{cat.title}</div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{cat.subtitle}</div>
            </div>
          </div>

          <div className="space-y-2">
            {cat.items.map((item) => (
              <div
                key={item.id}
                className={cn(
                  "islamic-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-3",
                  completed[item.id] ? "bg-islamic-green/5 dark:bg-islamic-gold/5 border-islamic-green/20" : "",
                )}
              >
                <div className="flex-1 min-w-0">
                  <div className="text-quran font-arabic text-sm leading-relaxed dark:text-slate-200">
                    {item.text}
                  </div>
                  <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                    {item.reference}
                    {item.count && (
                      <span className="ml-2 font-bold text-islamic-green dark:text-islamic-gold">
                        {item.count} مرة
                      </span>
                    )}
                  </div>
                </div>

                {cat.id === "tasbih" && activeTasbih === item.id ? (
                  <div className="flex flex-col items-center gap-2 w-full md:w-auto">
                    <div className="text-2xl font-mono font-bold text-islamic-green dark:text-islamic-gold">
                      {tasbihCount}
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => handleDecrement(item.id)}
                        className="w-8 h-8 rounded-full border border-slate-200 dark:border-white/20 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleIncrement(item.id)}
                        className="w-8 h-8 rounded-full bg-islamic-green text-white flex items-center justify-center shadow-md hover:bg-green-700"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleReset(item.id)}
                        className="w-8 h-8 rounded-full border border-slate-200 dark:border-white/20 flex items-center justify-center text-slate-500 dark:text-slate-400"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleIncrement(item.id)}
                      className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors",
                        countFor(item.id) > 0 ? "bg-islamic-green/10 text-islamic-green dark:bg-islamic-gold/10 dark:text-islamic-gold" : "",
                      )}
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                    <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-200 w-5 text-center">
                      {countFor(item.id)}
                    </span>
                    <button
                      onClick={() => handleDecrement(item.id)}
                      className="w-8 h-8 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => toggleComplete(item.id)}
                      className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center text-slate-400 transition-colors",
                        completed[item.id]
                          ? "text-islamic-green dark:text-islamic-gold"
                          : "hover:text-slate-900 dark:hover:text-white",
                      )}
                    >
                      {completed[item.id] ? (
                        <Check className="w-4 h-4" />
                      ) : (
                        <Play className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
