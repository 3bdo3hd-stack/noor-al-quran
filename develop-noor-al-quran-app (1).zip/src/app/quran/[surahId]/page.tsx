import { getSurah } from "@/lib/quran";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ClientAyahRow } from "@/components/quran/ayah-row";

export default async function SurahPage({
  params,
}: {
  params: Promise<{ surahId: string }>;
}) {
  const { surahId: raw } = await params;
  const surahId = parseInt(raw, 10);
  const surah = getSurah(surahId);
  if (!surah) notFound();

  const prev = surahId > 1 ? surahId - 1 : null;
  const next = surahId < 114 ? surahId + 1 : null;

  return (
    <div className="mx-auto max-w-4xl px-5 py-6 lg:py-10 space-y-6">
      <nav className="flex items-center justify-between gap-3 border-b border-white/60 dark:border-white/10 pb-4">
        <Link href="/quran" className="text-sm text-slate-500 dark:text-slate-400 hover:text-islamic-green dark:hover:text-islamic-gold">
          ← العودة إلى قائمة السور
        </Link>
        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span>الصفحة {surah.ayahs[0].page}</span>
          <span className="mx-1 text-slate-300">·</span>
          <span>{surah.totalAyahs} آية</span>
          <span className="mx-1 text-slate-300">·</span>
          <span>الجزء {surah.ayahs[0].juzId}</span>
        </div>
      </nav>

      <header className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-islamic-green-dark dark:text-islamic-gold uppercase tracking-wider">
              {surah.revelationType === "mekki" ? "مكية" : "مدنية"}
            </span>
            <span className="text-xs text-slate-400 bg-white/50 dark:bg-white/10 rounded-full px-2 py-0.5">
              {surah.totalAyahs} آية
            </span>
          </div>
          <h1 className="font-arabic text-4xl font-bold text-slate-900 dark:text-white leading-tight">
            {surah.nameAr}
          </h1>
          <p className="mt-1 text-slate-500 dark:text-slate-400">
            {surah.nameEn} — الجزء {surah.ayahs[0].juzId}
          </p>
        </div>
      </header>

      <div className="space-y-1">
        {surah.ayahs.map((ayah) => (
          <ClientAyahRow key={ayah.id} ayah={ayah} surahId={surahId} />
        ))}
      </div>

      <div className="mt-10 flex justify-between gap-3">
        {prev && (
          <Link
            href={`/quran/${prev}`}
            className="islamic-card px-4 py-3 flex items-center gap-2 text-sm font-medium"
          >
            ← سورة {prev}
          </Link>
        )}
        {next && (
          <Link
            href={`/quran/${next}`}
            className="islamic-card px-4 py-3 flex items-center gap-2 text-sm font-medium ml-auto"
          >
            سورة {next} →
          </Link>
        )}
      </div>
    </div>
  );
}
