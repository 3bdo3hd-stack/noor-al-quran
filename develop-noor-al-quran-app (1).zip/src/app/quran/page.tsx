import { getSurahsWithCount, getPageCount, getJuzCount } from "@/lib/quran";
import Link from "next/link";

export default function QuranHubPage() {
  const surahs = getSurahsWithCount();
  const pageCount = getPageCount();
  const juzCount = getJuzCount();

  return (
    <div className="mx-auto max-w-7xl px-5 py-10 space-y-10">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="font-arabic text-3xl font-bold text-slate-900 dark:text-white">
            المصحف الشريف
          </h1>
          <p className="mt-1 text-slate-600 dark:text-slate-400">
            اقرأ القرآن بالرسم العثماني الصحيح، صفحة بصفحة أو سورة بسورة.
          </p>
        </div>
        <div className="flex gap-2">
          <Link
            href="/quran/1"
            className="islamic-btn flex items-center gap-2"
          >
            ابدأ من الفاتحة
          </Link>
        </div>
      </div>

      {/* Quick jump */}
      <section className="islamic-card p-6">
        <h2 className="font-arabic text-lg font-bold text-slate-900 dark:text-white mb-5">
          الانتقال السريع
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <JumpCard
            label="الصفحة"
            hint={`من 1 إلى ${pageCount}`}
            href="/quran/page/1"
            icon="📄"
          />
          <JumpCard
            label="الجزء"
            hint={`من 1 إلى ${juzCount}`}
            href="/juz/1"
            icon="﴿"
          />
          <JumpCard
            label="السورة"
            hint="اختر سورة"
            href="#surahs"
            icon="📖"
          />
        </div>
      </section>

      {/* Surah list */}
      <section id="surahs">
        <h2 className="font-arabic text-xl font-bold text-slate-900 dark:text-white mb-5 flex items-center gap-2">
          <span>﴿</span> جميع السور ({surahs.length})
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {surahs.map((s) => (
            <Link
              key={s.id}
              href={`/quran/${s.id}`}
              className="islamic-card p-4 flex flex-col gap-2 group"
            >
              <div className="flex items-center justify-between">
                <span className="font-arabic text-lg font-bold text-slate-900 dark:text-white group-hover:text-islamic-green dark:group-hover:text-islamic-gold transition-colors">
                  {s.nameAr}
                </span>
                <span className="text-xs font-medium text-islamic-green dark:text-islamic-gold bg-islamic-green/5 dark:bg-islamic-gold/10 rounded-full px-2.5 py-0.5">
                  {s.totalAyahs}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 capitalize">
                {s.revelationType === "mekki" ? "مكية" : "مدنية"}
              </p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}

function JumpCard({
  label,
  hint,
  href,
  icon,
}: {
  label: string;
  hint: string;
  href: string;
  icon: string;
}) {
  return (
    <div className="islamic-card p-5 flex flex-col gap-2">
      <div className="text-2xl">{icon}</div>
      <p className="font-bold text-slate-900 dark:text-white">{label}</p>
      <p className="text-xs text-slate-500 dark:text-slate-400">{hint}</p>
    </div>
  );
}
