"use client";

import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { Sun, Moon, Clock, Compass, MapPin, Calendar } from "lucide-react";

const DEFAULT_LAT = 21.4225; // Makkah
const DEFAULT_LNG = 39.8262;

const PRAYERS = [
  { key: "Fajr", label: "الفجر", icon: <Sun className="w-4 h-4" /> },
  { key: "Dhuhr", label: "الظهر", icon: <Sun className="w-4 h-4" /> },
  { key: "Asr", label: "العصر", icon: <Sun className="w-4 h-4" /> },
  { key: "Maghrib", label: "المغرب", icon: <Moon className="w-4 h-4" /> },
  { key: "Isha", label: "العشاء", icon: <Moon className="w-4 h-4" /> },
];

export default function PrayerPage() {
  const [timings, setTimings] = useState<Record<string, string> | null>(null);
  const [hijri, setHijri] = useState<any>(null);
  const [location, setLocation] = useState<{ lat: number; lng: number; name: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [method, setMethod] = useState("4");

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      const lat = location?.lat ?? DEFAULT_LAT;
      const lng = location?.lng ?? DEFAULT_LNG;
      try {
        const res = await fetch(`/api/prayer?lat=${lat}&lng=${lng}&method=${method}`);
        const data = await res.json();
        if (mounted && data.data) {
          setTimings(data.data.timings);
          setHijri(data.data.date.hijri);
        }
      } catch {
        // silently fail; UI shows empty state
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();
    return () => { mounted = false; };
  }, [location, method]);

  useEffect(() => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          name: "موقعك الحالي",
        });
      },
      () => {
        setLocation({ lat: DEFAULT_LAT, lng: DEFAULT_LNG, name: "مكة المكرمة (افتراضي)" });
      },
    );
  }, []);

  const nextPrayer = () => {
    if (!timings) return null;
    const now = new Date();
    const todayStr = now.toLocaleString("en-US", { timeZone: "Asia/Riyadh" });
    // Simplest: find first prayer time later than now today
    for (const p of PRAYERS) {
      const t = timings[p.key];
      if (!t) continue;
      const [h, m] = t.split(":").map(Number);
      const prayerTime = new Date();
      prayerTime.setHours(h, m, 0, 0);
      if (prayerTime > now) return { ...p, time: t, target: prayerTime };
    }
    // Otherwise first prayer tomorrow (Fajr)
    const p = PRAYERS[0];
    return { ...p, time: timings[p.key], target: null };
  };

  const np = nextPrayer();
  const remaining = np && np.target ? Math.max(0, Math.floor((np.target.getTime() - Date.now()) / 1000)) : 0;

  const qiblaBearing = (lat: number, lng: number) => {
    const kaaba = { lat: 21.4225, lng: 39.8262 };
    const toRad = (x: number) => (x * Math.PI) / 180;
    const dLon = toRad(kaaba.lng - lng);
    const y = Math.sin(dLon) * Math.cos(toRad(kaaba.lat));
    const x =
      Math.cos(toRad(lat)) * Math.sin(toRad(kaaba.lat)) -
      Math.sin(toRad(lat)) * Math.cos(toRad(kaaba.lat)) * Math.cos(dLon);
    let bearing = (Math.atan2(y, x) * 180) / Math.PI;
    bearing = (bearing + 360) % 360;
    return Math.round(bearing);
  };
  const bearing = location ? qiblaBearing(location.lat, location.lng) : null;

  if (loading) {
    return (
      <div className="mx-auto max-w-2xl px-5 py-12 text-center">
        <div className="flex items-center justify-center gap-2 text-islamic-green animate-spin">
          <Clock className="w-6 h-6" /> جاري جلب مواقيت الصلاة...
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-5 py-10 space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="font-arabic text-2xl font-bold text-slate-900 dark:text-white">
            مواقيت الصلاة
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {location?.name || "جاري تحديد الموقع"} — 방법 {method}
          </p>
        </div>
        <button
          onClick={() => {
            if (!navigator.geolocation) return;
            navigator.geolocation.getCurrentPosition(
              (pos) =>
                setLocation({
                  lat: pos.coords.latitude,
                  lng: pos.coords.longitude,
                  name: "موقعك الحالي",
                }),
              () => setLocation({ lat: DEFAULT_LAT, lng: DEFAULT_LNG, name: "مكة المكرمة (افتراضي)" }),
            );
          }}
          className="text-xs border border-white/60 dark:border-white/10 rounded-full px-2 py-1 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5"
        >
          <MapPin className="w-3 h-3 mr-1" /> تحديد الموقع
        </button>
      </div>

      {/* Qibla compass */}
      <div className="islamic-card p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-xs font-bold text-islamic-green-dark dark:text-islamic-gold uppercase tracking-wider">
              اتجاه القبلة
            </div>
            <div className="text-sm font-medium text-slate-700 dark:text-slate-300">
              {bearing !== null ? `${bearing}°` : "--"}°
            </div>
          </div>
          <Compass className="w-8 h-8 text-islamic-green dark:text-islamic-gold animate-spin" />
        </div>
        <div className="flex items-center justify-center">
          <div className="w-16 h-16 rounded-full border-2 border-islamic-green/30 dark:border-islamic-gold/30 flex items-center justify-center relative">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-3 bg-islamic-green dark:bg-islamic-gold" />
            <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400">ن</span>
          </div>
        </div>
        <p className="mt-3 text-xs text-slate-500 dark:text-slate-400 text-center">
          وجه هاتفك نحو الشمال، ثم ادور {bearing !== null ? bearing : 0} درجة باتجاه القبلة (تُحسب من موقعك).
        </p>
      </div>

      {/* Prayer times */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {timings
          ? PRAYERS.map((p) => {
              const isNext = np?.key === p.key;
              return (
                <div
                  key={p.key}
                  className={cn(
                    "islamic-card p-4 rounded-2xl flex flex-col items-center gap-2",
                    isNext ? "border-islamic-green bg-islamic-green/5 dark:border-islamic-gold dark:bg-islamic-gold/5" : "",
                  )}
                >
                  {p.icon}
                  <div className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider font-bold">
                    {p.label}
                  </div>
                  <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
                    {timings[p.key]}
                  </div>
                  {isNext && (
                    <div className="text-[10px] text-islamic-green dark:text-islamic-gold font-bold">
                      القادمة
                    </div>
                  )}
                </div>
              );
            })
          : PRAYERS.map((p) => (
              <div key={p.key} className="islamic-card p-4 flex flex-col items-center gap-2">
                {p.icon}
                <div className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider font-bold">{p.label}</div>
                <div className="text-2xl font-mono text-slate-400 dark:text-slate-500">--:--</div>
              </div>
            ))}
      </div>

      {np && (
        <div className="islamic-card p-4 flex items-center gap-3">
          <Clock className="w-5 h-5 text-islamic-green dark:text-islamic-gold" />
          <div>
            <div className="text-sm font-bold text-slate-900 dark:text-white">
             الصلاة القادمة: {np.label} ({np.time})
            </div>
            {np.target ? (
              <div className="text-xs text-slate-500 dark:text-slate-400">
                بقي: {formatRemaining(remaining)}
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Hijri date */}
      <div className="islamic-card p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Calendar className="w-5 h-5 text-islamic-green dark:text-islamic-gold" />
          <div>
            <div className="font-bold text-slate-900 dark:text-white">
              {hijri?.date} {hijri?.month.ar}
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400">
              {hijri?.weekday.ar} • {hijri?.year} هـ
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span>طريقة الحساب</span>
          <select
            value={method}
            onChange={(e) => setMethod(e.target.value)}
            className="bg-transparent text-slate-700 dark:text-slate-300 border-none focus:ring-0"
          >
            <option value="4">أم القرى (مكة)</option>
            <option value="2">رابطة العالم الإسلامي</option>
            <option value="3">جامعة القاهرة</option>
            <option value="8">جمعية هندسية</option>
          </select>
        </div>
      </div>
    </div>
  );
}

function formatRemaining(sec: number) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (h > 0) return `${h}س ${m}د ${s}ث`;
  if (m > 0) return `${m}د ${s}ث`;
  return `${s}ث`;
}
