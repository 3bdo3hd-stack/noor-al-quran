"use client";

import React, { useEffect, useState } from "react";
import { useUser } from "@/components/providers";
import { getUserBookmarks } from "@/app/actions";
import { getAyahById, SURAHS_BY_ID } from "@/lib/quran";
import Link from "next/link";

export default function BookmarksPage() {
  const { userId } = useUser();
  const [entries, setEntries] = useState<Array<any>>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      if (!userId) return;
      const rows = await getUserBookmarks(userId);
      if (!mounted) return;
      const list = rows.map((b: any) => {
        const ayah = getAyahById(b.ayahId);
        const surah = SURAHS_BY_ID.get(b.surahId);
        return { ...b, ayah, surahName: surah?.nameAr };
      });
      setEntries(list);
      setLoading(false);
    };
    load();
    return () => {
      mounted = false;
    };
  }, [userId]);

  return (
    <div className="mx-auto max-w-4xl px-5 py-10 space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="font-arabic text-2xl font-bold text-slate-900 dark:text-white">
          العلامات المرجعية
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          {entries.length} آية محفوظة
        </p>
      </div>

      {loading ? (
        <div className="islamic-card p-12 text-center">
          <p className="text-slate-500 dark:text-slate-400 animate-pulse">
            جاري تحميل علاماتك المرجعية...
          </p>
        </div>
      ) : entries.length === 0 ? (
        <div className="islamic-card p-12 text-center">
          <p className="text-slate-500 dark:text-slate-400">
            لا توجد علامات مرجعية بعد. أضف أي آية إلى المفضلة من صفحة السورة.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {entries.map((e: any) => (
            <Link
              key={e.id}
              href={`/quran/${e.surahId}`}
              className="islamic-card p-4 flex items-center gap-4 group"
            >
              <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-islamic-light dark:bg-white/10 flex items-center justify-center text-islamic-green dark:text-islamic-gold font-bold">
                {e.ayah?.numberInSurah}
              </div>
              <div className="flex-1 min-w-0">
                {e.ayah ? (
                  <div className="text-quran font-arabic text-sm dark:text-slate-200 truncate rtl:text-right">
                    {e.ayah.text}
                  </div>
                ) : (
                  <div className="text-sm text-slate-500 dark:text-slate-400">
                    آية غير متوفرة
                  </div>
                )}
                <div className="mt-1 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <span>{e.surahName}</span>
                  <span className="w-px h-3 bg-slate-300 dark:bg-white/20"></span>
                  <span>الآية {e.ayah?.numberInSurah}</span>
                </div>
              </div>
              <span className="text-slate-400 group-hover:text-islamic-green dark:group-hover:text-islamic-gold">
                →
              </span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
