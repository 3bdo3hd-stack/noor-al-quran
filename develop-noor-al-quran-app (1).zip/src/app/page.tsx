import { getAyahByGlobalNumber, getSurahsWithCount, getTotalAyahs } from "@/lib/quran";
import Link from "next/link";
import { Book, BookOpen, Mosque, Sparkles, Clock, Play } from "lucide-react";

const DAYS_INDEXED_VERSE = (() => {
  const dayOfYear = (() => {
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    const oneDay = 1000 * 60 * 60 * 24;
    return Math.floor(diff / oneDay);
  })();
  return ((dayOfYear % getTotalAyahs()) + 1);
})();

export default async function HomePage() {
  const dailyAyah = getAyahByGlobalNumber(DAYS_INDEXED_VERSE);
  const surahs = getSurahsWithCount();

  const quickActions = [
    {
      href: "/quran",
      label: "افتح المصحف",
      icon: Book,
      desc: "اقرأ/page-by-page",
    },
    {
      href: "/azkar",
      label: "الأذكار",
      icon: BookOpen,
      desc: "صباح، مساء، وبعد الصلاة",
    },
    {
      href: "/prayer",
      label: "مواقيت الصلاة",
      icon: Mosque,
      desc: "آخر تحديث لمدينتك",
    },
    {
      href: "/settings",
      label: "الإعدادات",
      icon: Sparkles,
      desc: "الخط، الحجم، المظهر",
    },
  ];

  return (
    <div className="mx-auto max-w-7xl px-5 py-10 space-y-10">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="font-arabic text-3xl font-bold text-slate-900 dark:text-white">
            أهلاً في نور القرآن
          </h1>
          <p className="mt-1 text-slate-600 dark:text-slate-400">
            مصحف عثماني صحيح، تلاوات، تفسير، أذكار، ومواقيت صلاة.
          </p>
        </div>
        <div className="flex gap-2">
          <Link
            href="/quran"
            className="islamic-btn flex items-center gap-2"
          >
            <Play className="w-4 h-4" /> ابدأ القراءة
          </Link>
        </div>
      </div>

      {/* Daily verse card */}
      <section className="islamic-card p-6 md:p-8">
        <div className="flex flex-col md:flex-row md:items-center gap-6">
          <div className="flex-shrink-0 w-16 h-16 rounded-2xl border border-islamic-green/20 bg-islamic-green/5 flex items-center justify-center text-islamic-green font-bold text-2xl">
            {DAYS_INDEXED_VERSE}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-islamic-green-dark dark:text-islamic-gold">
                آية اليوم
              </span>
              {dailyAyah && (
                <span className="ml-auto text-xs text-slate-500 dark:text-slate-400">
                  سورة {dailyAyah ? (surahs.find((s) => s.id === dailyAyah.surahId)?.nameAr) : ""}
                </span>
              )}
            </div>
            {dailyAyah ? (
              <>
                <div className="text-quran font-arabic text-xl dark:text-slate-200 mb-3 rtl:text-right">
                  {dailyAyah.text}
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <span>آية {dailyAyah.numberInSurah}</span>
                  <span className="w-px h-3 bg-slate-300 dark:bg-white/20"></span>
                  <span>الصفحة {dailyAyah.page}</span>
                </div>
              </>
            ) : (
              <div className="text-slate-500">جاري تحميل الآية...</div>
            )}
          </div>
        </div>
      </section>

      {/* Stats row */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard
          label="إجمالي الآيات في القرآن"
          value={getTotalAyahs().toLocaleString()}
          icon={Book}
        />
        <StatCard label="عدد السور" value="114" icon={BookOpen} />
        <StatCard label="الجزء الحالي" value="1 من 30" icon={Clock} />
      </section>

      {/* Quick actions */}
      <section>
        <h2 className="font-arabic text-xl font-bold text-slate-900 dark:text-white mb-5">
          الوصول السريع
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <Link
                key={action.href}
                href={action.href}
                className="islamic-card p-5 flex flex-col gap-3 hover:shadow-[0_12px_40px_rgba(6,59,43,0.12)] dark:hover:shadow-[0_12px_40px_rgba(0,0,0,0.4)] transition-all duration-200 group"
              >
                <div className="w-10 h-10 rounded-xl bg-islamic-light dark:bg-white/10 flex items-center justify-center text-islamic-green dark:text-islamic-gold group-hover:scale-110 transition-transform">
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white">
                    {action.label}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{action.desc}</p>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Recent surahs */}
      <section>
        <h2 className="font-arabic text-xl font-bold text-slate-900 dark:text-white mb-5 flex items-center gap-2">
          <Book className="w-5 h-5 text-islamic-green" /> السور recientes
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {surahs.slice(0, 8).map((s) => (
            <Link
              key={s.id}
              href={`/quran/${s.id}`}
              className="islamic-card p-4 flex flex-col gap-2"
            >
              <div className="flex items-center justify-between">
                <span className="font-arabic text-lg font-bold text-slate-900 dark:text-white">
                  {s.nameAr}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400 bg-white/50 dark:bg-white/10 rounded-full px-2 py-0.5">
                  {s.totalAyahs}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {s.revelationType === "mekki" ? "مكية" : "مدنية"}
              </p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}

function StatCard({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string | number;
  icon: any;
}) {
  return (
    <div className="islamic-card p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            {label}
          </p>
          <p className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">
            {value}
          </p>
        </div>
        <div className="w-9 h-9 rounded-lg bg-islamic-light dark:bg-white/10 flex items-center justify-center text-islamic-green dark:text-islamic-gold">
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
}
