"use server";

import { db } from "@/db";
import {
  users,
  bookmarks,
  lastRead,
  memorizationProgress,
  azkarProgress,
  readingStats,
} from "@/db/schema";
import { eq, and } from "drizzle-orm";

const GUEST_EMAIL = "guest@noor.local";

export async function ensureUser() {
  "use server";
  let [user] = await db
    .select()
    .from(users)
    .where(eq(users.email, GUEST_EMAIL));
  if (!user) {
    [user] = await db
      .insert(users)
      .values({
        email: GUEST_EMAIL,
        name: "ضيف نور القرآن",
        language: "ar",
      })
      .returning();
  }
  return user;
}

export async function toggleBookmark({
  userId,
  surahId,
  ayahId,
  note,
}: {
  userId: number;
  surahId: number;
  ayahId: number;
  note?: string;
}) {
  "use server";
  const [existing] = await db
    .select()
    .from(bookmarks)
    .where(
      and(
        eq(bookmarks.userId, userId),
        eq(bookmarks.surahId, surahId),
        eq(bookmarks.ayahId, ayahId),
      ),
    );
  if (existing) {
    await db.delete(bookmarks).where(eq(bookmarks.id, existing.id));
    return { added: false };
  }
  await db.insert(bookmarks).values({ userId, surahId, ayahId, note });
  return { added: true };
}

export async function setLastRead({
  userId,
  surahId,
  ayahId,
}: {
  userId: number;
  surahId: number;
  ayahId: number;
}) {
  "use server";
  const [lr] = await db
    .select()
    .from(lastRead)
    .where(eq(lastRead.userId, userId));
  if (lr) {
    await db
      .update(lastRead)
      .set({ surahId, ayahId, updatedAt: new Date() })
      .where(eq(lastRead.userId, userId));
  } else {
    await db.insert(lastRead).values({ userId, surahId, ayahId });
  }
  return { ok: true };
}

export async function toggleMemorized({
  userId,
  surahId,
  ayahId,
}: {
  userId: number;
  surahId: number;
  ayahId: number;
}) {
  "use server";
  const [existing] = await db
    .select()
    .from(memorizationProgress)
    .where(
      and(
        eq(memorizationProgress.userId, userId),
        eq(memorizationProgress.surahId, surahId),
        eq(memorizationProgress.ayahId, ayahId),
      ),
    );
  if (existing) {
    await db
      .update(memorizationProgress)
      .set({ memorized: !existing.memorized, updatedAt: new Date() })
      .where(eq(memorizationProgress.id, existing.id));
    return { memorized: !existing.memorized };
  }
  await db.insert(memorizationProgress).values({
    userId,
    surahId,
    ayahId,
    memorized: true,
  });
  return { memorized: true };
}

export async function upsertAzkar({
  userId,
  category,
  itemId,
  count,
}: {
  userId: number;
  category: string;
  itemId: string;
  count: number;
}) {
  "use server";
  const [existing] = await db
    .select()
    .from(azkarProgress)
    .where(
      and(
        eq(azkarProgress.userId, userId),
        eq(azkarProgress.category, category),
        eq(azkarProgress.itemId, itemId),
      ),
    );
  const completedToday = count > 0;
  if (existing) {
    await db
      .update(azkarProgress)
      .set({
        count: existing.count + count,
        completedToday,
        updatedAt: new Date(),
      })
      .where(eq(azkarProgress.id, existing.id));
  } else {
    await db.insert(azkarProgress).values({
      userId,
      category,
      itemId,
      count,
      completedToday,
    });
  }
  return { ok: true };
}

export async function getUserBookmarks(userId: number) {
  "use server";
  return db
    .select()
    .from(bookmarks)
    .where(eq(bookmarks.userId, userId))
    .orderBy(bookmarks.createdAt);
}

export async function getUserLastRead(userId: number) {
  "use server";
  return db.select().from(lastRead).where(eq(lastRead.userId, userId));
}

export async function getUserMemorized(userId: number) {
  "use server";
  return db
    .select()
    .from(memorizationProgress)
    .where(eq(memorizationProgress.userId, userId));
}

export async function getTodaysReadingStats(userId: number) {
  "use server";
  const today = new Date().toISOString().slice(0, 10);
  return db
    .select()
    .from(readingStats)
    .where(eq(readingStats.userId, userId));
}
