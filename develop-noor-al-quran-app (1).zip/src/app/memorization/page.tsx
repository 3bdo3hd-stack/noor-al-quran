"use client";

import React, { useEffect, useState } from "react";
import { useUser } from "@/components/providers";
import { getUserMemorized } from "@/app/actions";
import { getSurahsWithCount, AYAHS, SURAHS_BY_ID } from "@/lib/quran";
import Link from "next/link";

export default function MemorizationPage() {
  const { userId } = useUser();
  const [surahs, setSurahs] = useState<Array<any>>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      const allSurahs = getSurahsWithCount();
      let memorizedRows: any[] = [];
      if (userId) {
        memorizedRows = await getUserMemorized(userId);
      }
      if (!mounted) return;
      const memorizedSet = new Set(
        memorizedRows.filter((p: any) => p.memorized).map(
          (p: any) => `${p.surahId}-${p.ayahId}`,
        ),
      );
      const list = allSurahs.map((s: any) => {
        const ayahs = (AYAHS as any[]).filter((a: any) => a.surahId === s.id);
        const memCount = ayahs.filter(
          (a: any) => memorizedSet.has(`${s.id}-${a.id}`),
        ).length;
        const pct = s.totalAyahs ? Math.round((memCount / s.totalAyahs) * 100) : 0;
        return { ...s, memCount, pct };
      });
      setSurahs(list);
      setLoading(false);
    };
    load();
    return () => {
      mounted = false;
    };
  }, [userId]);

  if (loading) {
    return (
      <div className="mx-auto max-w-4xl px-5 py-12 text-center">
        <p className="text-slate-500 dark:text-slate-400 animate-pulse">
          جاري تحميل تقدم الحفظ...
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-5 py-10 space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="font-arabic text-2xl font-bold text-slate-900 dark:text-white">
          مساعد الحفظ
        </h1>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-islamic-green-dark dark:text-islamic-gold bg-islamic-green/5 dark:bg-islamic-gold/10 px-2 py-0.5 rounded">
            {
              surahs.reduce((acc: number, s: any) => acc + s.memCount, 0)
            } آية محفوظة
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {surahs.map((s: any) => (
          <Link
            key={s.id}
            href={`/memorization/${s.id}`}
            className="islamic-card p-5 flex flex-col gap-3"
          >
            <div className="flex items-center justify-between">
              <span className="font-arabic font-bold text-slate-900 dark:text-white">
                {s.nameAr}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {s.pct}%
              </span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-white/10 rounded-full h-2">
              <div className="h-2 rounded-full bg-islamic-green dark:bg-islamic-gold" style={{ width: `${s.pct}%` }}></div>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {s.memCount} من {s.totalAyahs} آية
            </p>
          </Link>
        ))}
      </div>

      <div className="islamic-card p-6">
        <h2 className="font-arabic text-lg font-bold text-slate-900 dark:text-white mb-4">
          كيف تستخدم المساعد
        </h2>
        <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300 list-disc pl-5 rtl:pl-0 rtl:pr-5">
          <li>افتح أي سورة من صفحة المصحف.</li>
          <li>اضغط على زر "علّم كمحفوظة" beside الآية بعد حفظها.</li>
          <li>يُعرض تقدمك في كل سورة أعلى الصفحة.</li>
        </ul>
      </div>
    </div>
  );
}
