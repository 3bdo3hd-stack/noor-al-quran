"use client";

import { useTheme } from "next-themes";
import { Sun, Moon, Globe, Check, Lock } from "lucide-react";
import { cn } from "@/lib/utils";

export default function SettingsPage() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="mx-auto max-w-2xl px-5 py-10 space-y-6">
      <h1 className="font-arabic text-2xl font-bold text-slate-900 dark:text-white">
        الإعدادات
      </h1>

      {/* Appearance */}
      <section className="islamic-card p-6">
        <h2 className="font-arabic text-lg font-bold text-slate-900 dark:text-white mb-5">
          المظهر والخط
        </h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium text-slate-900 dark:text-white">
                الوضع اللوني
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                اختيار بين الوضع الليلي والنهاري
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setTheme("light")}
                className={cn(
                  "w-6 h-6 rounded-full border p-[2px]",
                  theme === "light"
                    ? "border-islamic-green bg-white"
                    : "border-transparent",
                )}
              >
                <Sun className="w-3.5 h-3.5 text-slate-500" />
              </button>
              <button
                onClick={() => setTheme("dark")}
                className={cn(
                  "w-6 h-6 rounded-full border p-[2px]",
                  theme === "dark"
                    ? "border-islamic-gold bg-[#0a0f0e]"
                    : "border-transparent",
                )}
              >
                <Moon className="w-3.5 h-3.5 text-slate-400" />
              </button>
              <button
                onClick={() => setTheme("system")}
                className={cn(
                  "w-6 h-6 rounded-full border p-[2px] ml-1",
                  theme === "system"
                    ? "border-slate-500 bg-white dark:bg-slate-700"
                    : "border-transparent",
                )}
              />
            </div>
          </div>

          <div className="pt-2 border-t border-white/60 dark:border-white/10">
            <div className="flex items-center justify-between mb-2">
              <div className="font-medium text-slate-900 dark:text-white">
                حجم الخط
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                تكبير أو تصغير نص القرآن
              </div>
            </div>
            <div className="flex gap-1">
              {["صغير", "عادي", "كبير", "أكبر"].map((label) => (
                <button
                  key={label}
                  onClick={() => {}}
                  className="px-3 py-1.5 rounded text-xs border border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 border-t border-white/60 dark:border-white/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-slate-400" />
                <div>
                  <div className="font-medium text-slate-900 dark:text-white">
                    اللغة
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    العربية / English
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="w-5 h-5 rounded-full border border-slate-200 dark:border-white/20 text-[10px] font-bold flex items-center justify-center">
                  AR
                </button>
                <button className="w-5 h-5 rounded-full border border-transparent text-[10px] font-bold flex items-center justify-center text-slate-400">
                  EN
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Privacy */}
      <section className="islamic-card p-6">
        <h2 className="font-arabic text-lg font-bold text-slate-900 dark:text-white mb-5">
          الخصوصية والحساب
        </h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Lock className="w-4 h-4 text-slate-400" />
              <div>
                <div className="font-medium text-slate-900 dark:text-white">
                  بيانات المستخدم
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  يتم حفظ المفضلة والتقدم بشكل آمن، ولا تُشارك مع أي طرف ثالث.
                </div>
              </div>
            </div>
            <Check className="w-4 h-4 text-islamic-green" />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div>
                <div className="font-medium text-slate-900 dark:text-white">
                  العمل دون إنترنت
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  القرآن والنصوص متاحة بدون اتصال بعد التحميل الأول.
                </div>
              </div>
              <Check className="w-4 h-4 text-islamic-green" />
            </div>
          </div>
        </div>
      </section>

      <div className="islamic-card p-6 text-center">
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
          نور القرآن — تطبيق قرآني متكامل
        </p>
        <p className="text-xs text-slate-400 dark:text-slate-500">
          جميع النصوص القرآنية من مصدر موثوق (الرسم العثماني)، ولا تُولَّد
          بالذكاء الاصطناعي.
        </p>
      </div>
    </div>
  );
}
