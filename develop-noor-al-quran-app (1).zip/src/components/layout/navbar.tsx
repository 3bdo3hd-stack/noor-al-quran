"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X, Book, Mosque, Clock, BookOpen, Sparkles, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/", label: "الرئيسية", icon: Sparkles },
  { href: "/quran", label: "المصحف", icon: Book },
  { href: "/azkar", label: "الأذكار", icon: BookOpen },
  { href: "/prayer", label: "المواقيت", icon: Mosque },
  { href: "/settings", label: "الإعدادات", icon: Settings },
];

export function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = React.useState(false);

  return (
    <>
      <div className="sticky top-0 z-40 w-full border-b border-white/60 bg-white/80 backdrop-blur-md dark:border-white/10 dark:bg-[#0a0f0e]/80 shadow-sm">
        <div className="flex items-center justify-between px-5 py-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-islamic-green flex items-center justify-center text-white shadow-sm">
              <span className="text-sm font-bold">ن</span>
            </div>
            <Link
              href="/"
              className="font-arabic font-bold text-xl text-slate-900 dark:text-white tracking-tight"
            >
              نور القرآن
            </Link>
          </div>

          <div className="hidden md:flex items-center gap-1">
            {NAV.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-islamic-green/10 text-islamic-green dark:text-islamic-gold dark:bg-islamic-gold/10"
                      : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-white/5",
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </Link>
              );
            })}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setOpen(true)}
              className="md:hidden w-9 h-9 rounded-lg flex items-center justify-center border border-white/60 bg-white/80 text-slate-700 dark:border-white/20 dark:bg-white/5 dark:text-slate-200"
              aria-label="فتح القائمة"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile drawer */}
      <div
        className={cn(
          "fixed inset-0 z-50 flex flex-col",
          open
            ? "translate-x-0"
            : "rtl:-translate-x-full rtl:translate-y-0 !translate-x-full translate-y-0",
          "transition-transform duration-300 ease-in-out sm:hidden",
        )}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/60 bg-white/80 dark:border-white/10 dark:bg-[#0a0f0e]">
          <div className="font-arabic font-bold text-xl text-slate-900 dark:text-white">
            قائمة navigation
          </div>
          <button
            onClick={() => setOpen(false)}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <nav className="flex-1 px-5 py-4 space-y-1 overflow-y-auto">
          {NAV.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-islamic-green/10 text-islamic-green dark:text-islamic-gold dark:bg-islamic-gold/10"
                    : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-white/5",
                )}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
      {open && (
        <div
          className="fixed inset-0 z-40 lg:hidden bg-black/40 backdrop-blur-sm"
          onClick={() => setOpen(false)}
          aria-hidden="true"
        />
      )}
    </>
  );
}
