"use client";

import { useTheme } from "next-themes";
import { Sun, Moon } from "lucide-react";
import { cn } from "@/lib/utils";

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  const isDark = theme === "dark";
  return (
    <button
      onClick={() => setTheme(isDark ? "light" : "dark")}
      aria-label="تغيير المظهر"
      className={cn(
        "fixed top-4 rtl:right-4 left-4 z-50 w-10 h-10 rounded-full border border-white/60 bg-white/80 backdrop-blur text-slate-700",
        "dark:border-white/20 dark:bg-white/5 dark:text-slate-200 shadow-sm",
      )}
    >
      {isDark ? (
        <Sun className="w-5 h-5" />
      ) : (
        <Moon className="w-5 h-5" />
      )}
      <span className="sr-only">
        {isDark ? "الوضع النهاري" : "الوضع الليلي"}
      </span>
    </button>
  );
}
