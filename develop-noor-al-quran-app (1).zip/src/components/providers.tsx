"use client";

import { ThemeProvider as NextThemesProvider } from "next-themes";
import { AudioProvider } from "@/components/audio/audio-context";
import { ensureUser } from "@/app/actions";
import {
  useEffect,
  useState,
  createContext,
  useContext,
  type ReactNode,
} from "react";

const UserCtx = createContext<{ userId: number | null } | null>(null);

export function UserProvider({ children }: { children: ReactNode }) {
  const [userId, setUserId] = useState<number | null>(null);

  useEffect(() => {
    let mounted = true;
    ensureUser().then((u) => {
      if (mounted) setUserId(u.id);
    });
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <UserCtx.Provider value={{ userId }}>{children}</UserCtx.Provider>
  );
}

export function useUser() {
  const ctx = useContext(UserCtx);
  if (!ctx) throw new Error("useUser must be used within UserProvider");
  return ctx;
}

export function Providers({ children }: { children: ReactNode }) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="system"
      storageKey="noor-theme"
    >
      <AudioProvider>
        <UserProvider>{children}</UserProvider>
      </AudioProvider>
    </NextThemesProvider>
  );
}
