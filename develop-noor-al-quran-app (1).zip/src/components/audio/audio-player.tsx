"use client";

import { useAudio, type Reciter } from "@/components/audio/audio-context";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Repeat,
  Volume2,
  VolumeOff,
  Clock,
  Menu,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { getSurah } from "@/lib/quran";

export function AudioPlayer() {
  const {
    isPlaying,
    current,
    duration,
    position,
    volume,
    speed,
    reciter,
    repeat,
    playPause,
    playNext,
    playPrev,
    stop,
    setVolume,
    setSpeed,
    setReciter,
    setRepeat,
    seek,
  } = useAudio();

  if (!current) return null;

  const surah = getSurah(current.surahId);
  const progress = duration > 0 ? (position / duration) * 100 : 0;

  return (
    <div className="fixed bottom-0 left-0 rtl:right-0 rtl:left-auto w-full z-[60] border-t border-white/60 bg-white/90 backdrop-blur-xl dark:border-white/10 dark:bg-[#0a0f0e]/90 shadow-[0_-10px_40px_rgba(6,59,43,0.25)]">
      <div className="mx-auto max-w-5xl px-5 py-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Current ayah info */}
          <div className="md:col-span-5 flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-islamic-green dark:text-islamic-gold uppercase tracking-wider">
                تلاوة
              </span>
              {surah && (
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  {surah.nameAr}
                </span>
              )}
            </div>
            <div className="font-arabic text-sm font-bold text-slate-900 dark:text-white">
              آية {current.ayahInSurah}
            </div>
          </div>

          {/* Controls */}
          <div className="md:col-span-4 flex flex-col items-center gap-3">
            <div
              className="w-full max-w-xs h-1 w-full rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden"
            >
              <div
                className="h-full bg-islamic-green dark:bg-islamic-gold"
                style={{ width: `${Math.min(progress, 100)}%` }}
              />
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span>{formatTime(position)}</span>
              <span className="mx-1">/</span>
              <span>{formatTime(duration)}</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={playPrev}
                className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
                title="السابقة"
              >
                <SkipBack className="w-5 h-5" />
              </button>
              <button
                onClick={playPause}
                className="w-10 h-10 rounded-full bg-islamic-green text-white flex items-center justify-center shadow-lg hover:bg-green-700 dark:shadow-[0_0_20px_rgba(201,162,39,0.3)] transition-colors"
                title={isPlaying ? "إيقاف مؤقت" : "تشغيل"}
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5" />
                ) : (
                  <Play className="w-5 h-5" />
                )}
              </button>
              <button
                onClick={playNext}
                className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
                title="التالية"
              >
                <SkipForward className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Settings */}
          <div className="md:col-span-3 flex flex-col md:items-end gap-2">
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <button
                onClick={() => setRepeat(!repeat)}
                aria-pressed={repeat}
                className={cn(
                  "p-1.5 rounded hover:bg-slate-100 dark:hover:bg-white/10 transition-colors",
                  repeat
                    ? "text-islamic-green bg-islamic-green/10 dark:text-islamic-gold dark:bg-islamic-gold/10"
                    : "text-slate-400",
                )}
                title="تكرار الآية"
              >
                <Repeat className="w-4 h-4" />
              </button>
              <span className="font-medium">تكرار</span>
              <button
                onClick={() => setSpeed(speed === 1 ? 1.5 : speed === 1.5 ? 2 : 1)}
                className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-white/10 text-slate-500 transition-colors"
                title="السرعة"
              >
                <Clock className="w-4 h-4" /> {speed}x
              </button>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setVolume(volume > 0 ? 0 : 1)}
                className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-white/10 text-slate-500 transition-colors"
                title="الصوت"
              >
                {volume > 0 ? (
                  <Volume2 className="w-4 h-4" />
                ) : (
                  <VolumeOff className="w-4 h-4" />
                )}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-20 h-1 bg-slate-200 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-islamic-green"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 dark:text-slate-400">القارئ</span>
              <button
                onClick={() => {
                  const reciters: Reciter[] = ["ar.alafasy", "ar.abdul_basit", "ar.minshawi", "ar.sudais"];
                  const idx = reciters.indexOf(reciter);
                  const next = reciters[(idx + 1) % 4];
                  setReciter(next);
                }}
                className="px-2.5 py-1 rounded bg-slate-100 dark:bg-white/10 text-xs text-slate-700 dark:text-slate-300 hover:bg-islamic-gold hover:text-white transition-colors"
              >
                {reciter}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function formatTime(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}
