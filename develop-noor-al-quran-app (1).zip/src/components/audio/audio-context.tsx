"use client";

import {
  createContext,
  useContext,
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import Howl from "howler";

export type Reciter = "ar.alafasy" | "ar.abdul_basit" | "ar.minshawi" | "ar.sudais";

const RECITERS: Reciter[] = [
  "ar.alafasy",
  "ar.abdul_basit",
  "ar.minshawi",
  "ar.sudais",
];

export interface AudioState {
  isPlaying: boolean;
  current: { surahId: number; ayahInSurah: number; globalNumber: number } | null;
  duration: number;
  position: number;
  volume: number;
  speed: number;
  reciter: Reciter;
  repeat: boolean;
  ready: boolean;
  error: string | null;
}

export interface AudioContextType extends AudioState {
  playAyah: (surahId: number, ayahInSurah: number) => void;
  playPause: () => void;
  playNext: () => void;
  playPrev: () => void;
  stop: () => void;
  setVolume: (v: number) => void;
  setSpeed: (v: number) => void;
  setReciter: (r: Reciter) => void;
  setRepeat: (v: boolean) => void;
  seek: (pos: number) => void;
}

const AudioCtx = createContext<AudioContextType | null>(null);

let howlRef: Howl | null = null;
let positionInterval: NodeJS.Timeout | null = null;

const baseUrl = (reciter: Reciter, globalNumber: number) =>
  `https://cdn.islamic.network/quran/audio/128/${reciter}/${globalNumber}.mp3`;

export function AudioProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AudioState>({
    isPlaying: false,
    current: null,
    duration: 0,
    position: 0,
    volume: 1,
    speed: 1,
    reciter: "ar.alafasy",
    repeat: false,
    ready: false,
    error: null,
  });

  const ensureHowl = useCallback(() => {
    if (!howlRef) {
      howlRef = new Howl({
        html5: true,
        volume: state.volume,
        rate: state.speed,
        autoplay: false,
        preload: true,
      });
    }
    return howlRef;
  }, [state.volume, state.speed]);

  useEffect(() => {
    if (howlRef) {
      howlRef.volume(state.volume);
      howlRef.rate(state.speed);
    }
  }, [state.volume, state.speed]);

  const clearPosInterval = useCallback(() => {
    if (positionInterval) {
      window.clearInterval(positionInterval);
      positionInterval = null;
    }
  }, []);

  const updatePosition = useCallback(() => {
    if (!howlRef || !howlRef.playing()) return;
    const pos = howlRef.seek() || 0;
    const dur = howlRef.duration() || 0;
    setState((s) => ({ ...s, position: pos, duration: dur }));
  }, []);

  const playUrl = useCallback(
    (globalNumber: number, auto = true) => {
      const h = ensureHowl();
      const url = baseUrl(state.reciter, globalNumber);
      h.src([url]);
      h.once("load", () => {
        setState((s) => ({ ...s, ready: true, error: null }));
        if (auto) h.play();
      });
      h.once("loaderror", () => {
        setState((s) => ({ ...s, ready: false, error: "تعذر تحميل الصوت" }));
      });
      h.once("play", () => {
        clearPosInterval();
        positionInterval = setInterval(updatePosition, 1000);
        setState((s) => ({ ...s, isPlaying: true, ready: true }));
      });
      h.once("end", () => {
        clearPosInterval();
        setState((s) => ({ ...s, isPlaying: false }));
        if (!state.repeat) {
          // do nothing here; playNext handles queue externally
        }
      });
      h.once("playerror", () => {
        setState((s) => ({ ...s, error: "تعذر تشغيل الصوت", isPlaying: false }));
      });
    },
    [state.reciter, state.repeat, ensureHowl, clearPosInterval, updatePosition],
  );

  const playAyah = useCallback(
    (surahId: number, ayahInSurah: number) => {
      const { getAyahByGlobalNumber } = require("@/lib/quran");
      // Find global number by scanning is expensive; instead derive from caller.
      // We expect callers to pass globalNumber via a helper. To keep simple, search.
      const ayahs = require("@/lib/quran").AYAHS;
      const a = ayahs.find(
        (x: any) => x.surahId === surahId && x.numberInSurah === ayahInSurah,
      );
      if (!a) return;
      setState((s) => ({ ...s, current: { surahId, ayahInSurah, globalNumber: a.number } }));
      playUrl(a.number, true);
    },
    [playUrl],
  );

  const playNext = useCallback(() => {
    if (!state.current) return;
    const { getNextAyah } = require("@/lib/quran");
    const next = getNextAyah(state.current.surahId, state.current.ayahInSurah);
    if (!next) return;
    const ayahs = require("@/lib/quran").AYAHS;
    const a = ayahs.find(
      (x: any) =>
        x.surahId === next.surahId && x.numberInSurah === next.ayahInSurah,
    );
    if (!a) return;
    setState((s) => ({
      ...s,
      current: { surahId: next.surahId, ayahInSurah: next.ayahInSurah, globalNumber: a.number },
    }));
    playUrl(a.number, true);
  }, [state.current, playUrl]);

  const playPrev = useCallback(() => {
    if (!state.current) return;
    const { getPrevAyah } = require("@/lib/quran");
    const prev = getPrevAyah(state.current.surahId, state.current.ayahInSurah);
    if (!prev) return;
    const ayahs = require("@/lib/quran").AYAHS;
    const a = ayahs.find(
      (x: any) =>
        x.surahId === prev.surahId && x.numberInSurah === prev.ayahInSurah,
    );
    if (!a) return;
    setState((s) => ({
      ...s,
      current: { surahId: prev.surahId, ayahInSurah: prev.ayahInSurah, globalNumber: a.number },
    }));
    playUrl(a.number, true);
  }, [state.current, playUrl]);

  const playPause = useCallback(() => {
    const h = ensureHowl();
    if (state.isPlaying) {
      h.pause();
      setState((s) => ({ ...s, isPlaying: false }));
    } else {
      h.play();
      setState((s) => ({ ...s, isPlaying: true }));
    }
  }, [state.isPlaying, ensureHowl]);

  const stop = useCallback(() => {
    const h = ensureHowl();
    h.stop();
    clearPosInterval();
    setState({ isPlaying: false, current: null, duration: 0, position: 0, volume: state.volume, speed: state.speed, reciter: state.reciter, repeat: state.repeat, ready: false, error: null });
  }, [clearPosInterval, state]);

  const setVolume = useCallback((v: number) => {
    setState((s) => ({ ...s, volume: v }));
    const h = ensureHowl();
    if (h) h.volume(v);
  }, [ensureHowl]);

  const setSpeed = useCallback((v: number) => {
    setState((s) => ({ ...s, speed: v }));
    const h = ensureHowl();
    if (h) h.rate(v);
  }, [ensureHowl]);

  const setReciter = useCallback((r: Reciter) => {
    setState((s) => ({ ...s, reciter: r }));
  }, []);

  const setRepeat = useCallback((v: boolean) => {
    setState((s) => ({ ...s, repeat: v }));
  }, []);

  const seek = useCallback((pos: number) => {
    const h = ensureHowl();
    if (h) h.seek(pos);
  }, [ensureHowl]);

  return (
    <AudioCtx.Provider
      value={{
        ...state,
        playAyah,
        playPause,
        playNext,
        playPrev,
        stop,
        setVolume,
        setSpeed,
        setReciter,
        setRepeat,
        seek,
      }}
    >
      {children}
    </AudioCtx.Provider>
  );
}

export function useAudio() {
  const ctx = useContext(AudioCtx);
  if (!ctx) throw new Error("useAudio must be used within AudioProvider");
  return ctx;
}
