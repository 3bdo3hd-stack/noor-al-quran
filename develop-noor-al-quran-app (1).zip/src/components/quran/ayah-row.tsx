"use client";

import React from "react";
import { useAudio } from "@/components/audio/audio-context";
import { toggleBookmark as tb, setLastRead as slr, toggleMemorized as tm } from "@/app/actions";
import { Bookmark, Copy, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { useUser } from "@/components/providers";
import { setLastRead } from "@/app/actions";

interface ClientAyahRowProps {
  ayah: any;
  surahId: number;
}

export function ClientAyahRow({ ayah, surahId }: ClientAyahRowProps) {
  const { playAyah, isPlaying, current } = useAudio();
  const { userId } = useUser();
  const isCurrent =
    current &&
    current.surahId === surahId &&
    current.ayahInSurah === ayah.numberInSurah;
  const [bookmarked, setBookmarked] = React.useState(false);
  const [memorized, setMemorized] = React.useState(false);
  const ready = userId != null;

  return (
    <div
      className={cn(
        "group relative flex items-center gap-3 rounded-xl border border-transparent p-3 hover:border-islamic-green/30 dark:hover:border-islamic-gold/20 hover:bg-islamic-green/5 dark:hover:bg-white/5 transition-colors cursor-pointer",
        isCurrent ? "bg-islamic-green/10 dark:bg-islamic-gold/10 border-islamic-green/30" : "",
      )}
      onClick={() => {
        playAyah(surahId, ayah.numberInSurah);
        if (userId) setLastRead({ userId, surahId, ayahId: ayah.id });
      }}
    >
      <div className="flex-1 text-quran font-arabic rtl:text-right">
        {ayah.text}
      </div>

      <span className="flex-shrink-0 w-7 h-7 rounded-full border border-islamic-green/40 bg-white dark:bg-white/5 flex items-center justify-center text-xs font-bold text-islamic-green dark:text-islamic-gold text-[11px]">
        {ayah.numberInSurah}
      </span>

      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          disabled={!ready}
          onClick={(e) => {
            e.stopPropagation();
            if (!userId) return;
            tb({ userId, surahId, ayahId: ayah.id }).then((r) =>
              setBookmarked(r.added),
            );
          }}
          className={cn(
            "w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-islamic-green dark:text-slate-500 dark:hover:text-islamic-gold transition-colors",
            bookmarked ? "text-islamic-green bg-islamic-green/10 dark:text-islamic-gold dark:bg-islamic-gold/10" : "",
          )}
          title={bookmarked ? "إزالة من المفضلة" : "إضافة للمفضلة"}
        >
          <Bookmark className="w-3.5 h-3.5" fill={bookmarked ? "currentColor" : "none"} stroke="currentColor" />
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigator.clipboard.writeText(ayah.text);
          }}
          className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-900 dark:text-slate-500 dark:hover:text-white transition-colors"
          title="نسخ الآية"
        >
          <Copy className="w-3.5 h-3.5" />
        </button>
        <button
          disabled={!ready}
          onClick={(e) => {
            e.stopPropagation();
            if (!userId) return;
            tm({ userId, surahId, ayahId: ayah.id }).then((r) =>
              setMemorized(r.memorized),
            );
          }}
          className={cn(
            "w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-green-600 dark:text-slate-500 dark:hover:text-green-400 transition-colors",
            memorized ? "text-green-600 bg-green-50 dark:text-green-400 dark:bg-green-900/20" : "",
          )}
          title={memorized ? "محفوظة بالفعل" : "علّم كمحفوظة للحفظ"}
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
