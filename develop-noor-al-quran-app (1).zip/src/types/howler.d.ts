declare module "howler" {
  interface HowlOptions {
    src?: string | string[];
    html5?: boolean;
    volume?: number;
    rate?: number;
    autoplay?: boolean;
    preload?: boolean;
    [key: string]: any;
  }
  class Howl {
    constructor(options?: HowlOptions);
    src(urls: string | string[], ...args: any[]): this;
    play(): this;
    pause(): this;
    stop(): this;
    volume(vol?: number): any;
    rate(rate?: number): any;
    seek(pos?: number): any;
    duration(): number;
    playing(): boolean;
    once(event: string, fn: (...args: any[]) => void): this;
    on(event: string, fn: (...args: any[]) => void): this;
    off(event: string, fn?: (...args: any[]) => void): this;
    state(): string;
  }
  export default Howl;
}
