import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  unique,
  index,
} from "drizzle-orm/pg-core";

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    name: text("name"),
    email: text("email").unique(),
    passwordHash: text("password_hash"),
    avatarUrl: text("avatar_url"),
    theme: text("theme").default("system"), // light | dark | system
    fontSize: text("font_size").default("md"), // sm | md | lg | xl
    language: text("language").default("ar"), // ar | en
    lastReadAyahId: integer("last_read_ayah_id"),
    lastReadSurahId: integer("last_read_surah_id"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => ({
    emailIdx: index("users_email_idx").on(t.email),
  }),
);

export const bookmarks = pgTable(
  "bookmarks",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    surahId: integer("surah_id").notNull(),
    ayahId: integer("ayah_id").notNull(),
    note: text("note"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => ({
    userIdx: index("bookmarks_user_idx").on(t.userId),
    uniqueUserSurahAyah: unique(
      "bookmarks_unique_user_surah_ayah",
    ).on(t.userId, t.surahId, t.ayahId),
  }),
);

export const lastRead = pgTable(
  "last_read",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .unique()
      .references(() => users.id, { onDelete: "cascade" }),
    surahId: integer("surah_id").notNull(),
    ayahId: integer("ayah_id").notNull(),
    updatedAt: timestamp("updated_at")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (t) => ({
    userIdx: index("last_read_user_idx").on(t.userId),
  }),
);

export const memorizationPlans = pgTable(
  "memorization_plans",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    surahId: integer("surah_id").notNull(),
    fromAyah: integer("from_ayah").notNull(),
    toAyah: integer("to_ayah").notNull(),
    targetVersesPerDay: integer("target_verses_per_day")
      .default(1)
      .notNull(),
    completed: boolean("completed").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => ({
    userIdx: index("memorization_plans_user_idx").on(t.userId),
  }),
);

export const memorizationProgress = pgTable(
  "memorization_progress",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    surahId: integer("surah_id").notNull(),
    ayahId: integer("ayah_id").notNull(),
    memorized: boolean("memorized").default(false).notNull(),
    tested: boolean("tested").default(false).notNull(),
    testPassed: boolean("test_passed").default(false).notNull(),
    updatedAt: timestamp("updated_at")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (t) => ({
    userIdx: index("memorization_progress_user_idx").on(t.userId),
    uniqueUserSurahAyah: unique(
      "memorization_progress_unique_user_surah_ayah",
    ).on(t.userId, t.surahId, t.ayahId),
  }),
);

export const azkarProgress = pgTable(
  "azkar_progress",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    category: text("category").notNull(),
    itemId: text("item_id").notNull(),
    count: integer("count").default(0).notNull(),
    completedToday: boolean("completed_today").default(false).notNull(),
    updatedAt: timestamp("updated_at")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (t) => ({
    userIdx: index("azkar_progress_user_idx").on(t.userId),
    uniqueUserItem: unique("azkar_progress_unique_user_item").on(
      t.userId,
      t.category,
      t.itemId,
    ),
  }),
);

export const readingStats = pgTable(
  "reading_stats",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    date: text("date").notNull(), // YYYY-MM-DD
    ayahsRead: integer("ayahs_read").default(0).notNull(),
    minutesRead: integer("minutes_read").default(0).notNull(),
  },
  (t) => ({
    userIdx: index("reading_stats_user_idx").on(t.userId),
    uniqueUserDate: unique("reading_stats_unique_user_date").on(
      t.userId,
      t.date,
    ),
  }),
);

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Bookmark = typeof bookmarks.$inferSelect;
export type LastRead = typeof lastRead.$inferSelect;
export type MemorizationPlan = typeof memorizationPlans.$inferSelect;
export type MemorizationProgress = typeof memorizationProgress.$inferSelect;
export type AzkarProgress = typeof azkarProgress.$inferSelect;
export type ReadingStat = typeof readingStats.$inferSelect;
